<?php
class Products_model extends CI_Model {
    public function __construct() {
       parent::__construct();
    }


	public function login($username = "", $password = ""){
		$query = $this->db
				 ->select('uid, username, last_login')
				 ->where(array('email'=>$username,'password'=>$password))
				 ->from('users')
				 ->get();

		//echo "<pre>";print($this->db->last_query());exit();

		    if ( $query->num_rows() > 0 )
		    {
		    	$this->uid 			= $query->row_array()['uid'];
		    	$this->userName 	= $query->row_array()['username'];
		    	$this->lastLogin 	= $query->row_array()['last_login'];
		    	return true;
		    }

		
	}

	public function insertProduct($data){
		//insert the product details
		$this->db->insert("product", $data);
		return ($this->db->affected_rows() != 1) ? false : true;

	}
	public function getProducts($start = '', $length = ''){
		$query = $this->db->select('pid, name, categories, stock, price')->limit($length,$start)->from('product')->order_by('pid DESC')->get();
		return $query->result_object();
	}
	public function getProductDetails($start = '', $length = ''){
		$query = $this->db->select('name, short_description, image, price, was_price')->limit($length,$start)->from('product')->where('stock',1)->order_by('pid DESC')->get();
		return $query->result_object();
	}
	public function recordsTotal(){
		$query = $this->db->select('pid')->from('product')->get();
		return $query->num_rows();
	}
	public function getProductData($id){
		$query = $this->db->select('sku, name, description, short_description, categories, image, stock, price, was_price')->from('product')->where('pid',$id)->get();
		return $query->row_array();
	}

	public function updateProduct($data, $id){
		//update the product details
    	$this->db->where('pid', $id);
		$this->db->update("product", $data);
		return ($this->db->affected_rows() != 1) ? false : true;

	}
	public function deleteProduct($id){
		$this->db->where('pid',$id)->delete('product');
		return ($this->db->affected_rows() != 1) ? false : true;
	}

	public function instockCount(){
		$query = $this->db->select('pid')->from('product')->where('stock',1)->get();
		return $query->num_rows();
	}
	public function oosCount(){
		$query = $this->db->select('pid')->from('product')->where('stock',0)->get();
		return $query->num_rows();
	}
}
?>