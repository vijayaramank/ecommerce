<?php
class Login_model extends CI_Model {
	public $uid;
	public $userName;
	public $lastLogin;

    public function __construct() {
       parent::__construct();
    }


	public function login($username = "", $password = ""){
		$query = $this->db
				 ->select('uid, username, last_login')
				 ->where(array('email'=>$username,'password'=>$password))
				 ->from('users')
				 ->get();

		//echo "<pre>";print($this->db->last_query());exit();

		    if ( $query->num_rows() > 0 )
		    {
		    	$this->uid 			= $query->row_array()['uid'];
		    	$this->userName 	= $query->row_array()['username'];
		    	$this->lastLogin 	= $query->row_array()['last_login'];
		    	return true;
		    }

		
	}
}
?>