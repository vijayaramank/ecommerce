<?php
 defined('BASEPATH') OR exit('no direct access');

//Validate the Session
function isLogedIn(){
    if(!isset($_SESSION['username'])){
      redirect("login");
    }
  }

?>
