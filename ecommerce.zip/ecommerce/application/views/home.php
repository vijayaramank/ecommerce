<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Register - SB Admin</title>
        <link href="<?php echo base_url(); ?>assets/css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

         <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>

<style>   
#loadMore {  
  width: 200px;  
  color: #fff;  
  display: block;  
  text-align: center;  
  margin: 20px auto;  
  padding: 10px;  
  border-radius: 10px;  
  border: 1px solid transparent;  
  text-align: center;  
  font-size: 1.5em;  
  color: #fff;  
  font-weight: 700;  
  text-transform: uppercase;   
  background-color: #000;
}  
#loadMore:hover {  
  color: blue;  
  background-color: #fff;  
  border: 1px solid blue;  
  text-decoration: none;  
}  
</style>  

    </head>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#">Ecommerce</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	      <div class="navbar-nav">
	        <a class="nav-link active" aria-current="page" href="http://localhost/ecommerce/login">Log In</a>
	      </div>
	    </div>
	  </div>
	</nav>
	
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-12">
                                <div class="card shadow-lg border-0 rounded-lg mt-5" id="productList">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
             <a href = "#" id = "loadMore"> Load More </a> 

            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script type="text/javascript">
        	
        	$( document ).ready(function () {

        		setTimeout(function(){ $( "#loadMore" ).trigger( "click" ); }, 500);

        		

			  var scount = 9; 
			  $(".moreBox").slice(0, 3).show();
			    if ($(".blogBox:hidden").length != 0) {
			      $("#loadMore").show();
			    }   
			    $("#loadMore").on('click', function (e) {
			      e.preventDefault();
			      $.ajax({
			            url: "http://localhost/ecommerce/welcome/loadData/"+scount,
			            async: false,
			            success: function (data){
			                  $("#productList").append(data);
			            }
			        });
			      scount = scount+9;
			  });
			});
        </script>
    </body>
</html>
