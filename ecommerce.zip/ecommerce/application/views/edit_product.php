<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Ecommerce - SB Admin</title>
        <link href="<?php echo base_url(); ?>assets/css/styles.css" rel="stylesheet" />
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap5.min.css">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

            <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap5.min.js"></script>

    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.html">Ecommerce</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="#!">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="<?= base_url('dashboard'); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Interface</div>
                            <a class="nav-link collapsed <?= ($this->uri->segment(1)==='editProduct')?"active":""; ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseProducts" aria-expanded="<?= ($this->uri->segment(1)==='editProduct')?"true":"false"; ?>" aria-controls="collapseProducts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Products
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse <?= ($this->uri->segment(1)==='editProduct')?"show":""; ?>" id="collapseProducts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link " href="<?= base_url ('addProduct');?>">Add Product</a>
                                    <a class="nav-link <?= ($this->uri->segment(1)==='editProduct')?"active":""; ?>" href="<?= base_url ('products');?>">View Product</a>
                                </nav>
                            </div>
                            
                            <a class="nav-link" href="<?= base_url('logout'); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Logout
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        Ecommerce
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4"><?= $title; ?></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><?= $breadcrumb; ?></li>
                        </ol>

                        <?php if (validation_errors()){
                            echo ' <div class="alert alert-danger">' ;
                            echo validation_errors();
                            echo '</div>';                                 
                        }
                        ?>


                        <?php if( $this->session->flashdata('authErr') )
                        {
                           echo '<div class="alert alert-danger" role="alert">'.$this->session->flashdata('authErr').'</div>';
                        }?>

                        <div class="container-xl px-4 mt-4">
                        <div class="row">

                            <div class="col-xl-4">
                                <!-- Profile picture card-->
                                <div class="card mb-4 mb-xl-0">
                                    <div class="card-header">Product Image</div>
                                    <div class="card-body text-center">
                                        <!-- Profile picture image-->
                                        <img class="img-account-profile rounded-circle mb-2" src="<?= base_url("/assets/uploads/".$image); ?>" alt="">
                                        <!-- Profile picture help block-->
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-8">
                                <div class="card mb-4">
                                    <div class="card-header">Add Product</div>
                                    <div class="card-body">
                                        <form action="" method="post" enctype="multipart/form-data">
                                            <!-- Form Row-->
                                            <div class="row gx-3 mb-3">
                                                <div class="col-md-6">
                                                    <label class="small mb-1" for="inputSKU">SKU</label>
                                                    <input class="form-control" id="inputSKU" name="sku" type="text" placeholder="1234567890" value="<?= isset($sku)?set_value('sku', $sku):""; ?>" required readonly>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="small mb-1" for="inputname">Product Name</label>
                                                    <input class="form-control" id="inputname" name="name" type="text" placeholder="Enter your product name" value="<?= set_value('name',$name); ?>">
                                                </div>
                                            </div>

                                            <div class="row gx-3 mb-3">
                                                <div class="col-md-12">
                                                    <label class="small mb-1" for="inputDescription">Description</label>
                                                    <textarea class="form-control" id="inputDescription" type="text" placeholder="Enter your product description" name="inputDescription"><?= set_value('inputDescription', $description); ?></textarea> 
                                                </div>
                                                <div class="col-md-12">
                                                    <label class="small mb-1" for="inputShortDescription">Short Description</label>
                                                    <textarea class="form-control" id="inputShortDescription" type="text" placeholder="Enter your product short description" name="inputShortDescription" ><?= set_value('inputShortDescription', $short_description); ?></textarea> 
                                                </div>
                                            </div>

                                            <div class="row gx-3 mb-3">
                                                <div class="col-md-6">
                                                    <label class="small mb-1" for="inputPrice">Price</label>
                                                    <input class="form-control" id="inputPrice" type="number" placeholder="Enter your product price" name="inputPrice" value="<?= set_value('inputPrice', $price); ?>">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="small mb-1" for="inputWasPrice">Was Price</label>
                                                    <input class="form-control" id="inputWasPrice" type="number" placeholder="Enter your product was price" name="inputWasPrice" value="<?= set_value('inputWasPrice', $was_price); ?>">
                                                </div>
                                            </div>

                                            <div class="row gx-3 mb-3">
                                                <div class="col-md-6">
                                                      <label for="productFile" class="form-label">Product Image</label>
                                                      <input class="form-control" type="file" id="productFile" name="productFile">
                                                </div>
                                                <div class="col-md-6">
                                                <label class="small mb-1">Category</label>
                                                <select class="form-select" name="category" aria-label="Default select example">
                                                    <option selected="" disabled="">Select a Category:</option>
                                                    <?php
                                                        foreach($category as $row){
                                                          echo '<option value="'.$row.'" selected="'.(($categories == $row)?"selected":"").'" >'.$row.'</option>';
                                                        }
                                                    ?>
                                                </select>
                                              </div>
                                            </div>

                                            <div class="mb-3">
                                              <div class="col-md-6">
                                                  <div class="form-check form-switch">
                                                    <label class="form-check-label" for="inputStock">Is Instock</label>
                                                    <input name="inputStock" class="form-check-input" type="checkbox" id="inputStock" <?= ($stock == "1")?"checked='checked'":"" ?> >
                                                  </div>
                                                </div>
                                            </div>
                                            <!-- Submit button-->
                                            <?php if(isset($id)){?>
                                                <input type="hidden" name="id" value="<?= $id; ?>">
                                            <?php } ?>
                                            <button class="btn btn-primary" type="submit">Update Product</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url(); ?>assets/demo/chart-area-demo.js"></script>
        <script src="<?php echo base_url(); ?>assets/demo/chart-bar-demo.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/datatables-simple-demo.js"></script> -->
    </body>
</html>
