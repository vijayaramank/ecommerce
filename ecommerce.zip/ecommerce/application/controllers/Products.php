<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	public function __construct(){
		parent::__construct();
		isLogedIn();
		$this->load->model('Products_model');
	}


	public function index()
	{
	    $data['title']		="Products";
		$data['breadcrumb']	="Products";
		$this->load->view('products',$data);

	}//end index function

	public function addProduct(){
		if($this->input->method() === 'post'){

			//Validation
			$this->form_validation->set_rules('sku','SKU','required|min_length[5]|max_length[12]|is_unique[product.sku]');
			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('inputShortDescription','Short Description','required');
			$this->form_validation->set_rules('inputPrice','Price','required');
			$this->form_validation->set_rules('category','Category','required');

		    if($this->form_validation->run() == false)
		    {
		        $data['title']		="Add Product";
				$data['breadcrumb']	="Product &gt; Add Product";
				$data['category']	= array("Cloth", "Bag", "Mobile", "Computer");
				$this->load->view('add_product',$data);
		    }
		    else
		    {

		    	if(isset($_FILES['productFile']) && $_FILES['productFile']['name'] !== ""){
		    		$id=rand();
		    		$fileData = $this->do_upload($id);
		    	}

		        $insertData['sku'] = $this->input->post('sku');
		        $insertData['name'] = $this->input->post('name');
		        $insertData['description'] = $this->input->post('inputDescription');
		        $insertData['short_description'] = $this->input->post('inputShortDescription');
		        if(isset($fileData)){
		        	$insertData['image'] = $fileData['upload_data']['file_name'];
		        }
		        $insertData['price'] = $this->input->post('inputPrice');
		        $insertData['was_price'] = $this->input->post('inputWasPrice');
		        $insertData['categories'] = $this->input->post('category');
		        $insertData['stock'] = ($this->input->post('inputStock'))?"1":"0";
		        $insertData['is_active'] = "1";

		        $value = $this->Products_model->insertProduct($insertData);

		        if($value)
		        {
		        	$this->session->set_flashdata('authErr', 'Product successfully added.');
		        	redirect(base_url('addProduct'));
		        }
		        else
		        {
		            $this->session->set_flashdata('authErr', 'Something Wrong!');
		            $data['title']		="Add Product";
					$data['breadcrumb']	="Product &gt; Add Product";
					$data['category']	= array("Cloth", "Bag", "Mobile", "Computer");
					$this->load->view('add_product',$data);
		        }
		    }

		}else{
			$data['title']		="Add Product";
			$data['breadcrumb']	="Product &gt; Add Product";
			$data['category']	= array("Cloth", "Bag", "Mobile", "Computer");
			$this->load->view('add_product',$data);
		}
	}

	public function loadData($postData=""){
		
		if($this->input->method() === "get"){
			$list['draw'] 		= $this->input->get('draw')+1;
			$startLimit			= $this->input->get('start');
			$lengthLimit		= $this->input->get('length');
		}

		$list['data'] 			= $this->Products_model->getProducts($startLimit, $lengthLimit);
		$list['recordsTotal'] 	= $this->Products_model->recordsTotal();
		$list['recordsFiltered']= $this->Products_model->recordsTotal();
		echo (json_encode($list,true));
	}

	public function editProduct($id=''){
		if($this->input->method() === 'post'){

			//Validation
			$this->form_validation->set_rules('sku','SKU','required|min_length[5]|max_length[12]');
			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('inputShortDescription','Short Description','required');
			$this->form_validation->set_rules('inputPrice','Price','required');
			$this->form_validation->set_rules('category','Category','required');

		    if($this->form_validation->run() == false)
		    {
		    	$data 				= $this->Products_model->getProductData($id);
		        $data['title']		="Add Product";
				$data['breadcrumb']	="Product &gt; Add Product";
				$data['category']	= array("Cloth", "Bag", "Mobile", "Computer");
				$this->load->view('edit_product',$data);
		    }
		    else
		    {
		    	if(isset($_FILES['productFile']) && $_FILES['productFile']['name'] !== ""){
		    		$fileData = $this->do_upload($id);
		    	}
		    	
		        $insertData['sku'] = $this->input->post('sku');
		        $insertData['name'] = $this->input->post('name');
		        $insertData['description'] = $this->input->post('inputDescription');
		        $insertData['short_description'] = $this->input->post('inputShortDescription');
		        if(isset($fileData)){
		        	$insertData['image'] = $fileData['upload_data']['file_name'];
		        }
		        $insertData['price'] = $this->input->post('inputPrice');
		        $insertData['was_price'] = $this->input->post('inputWasPrice');
		        $insertData['categories'] = $this->input->post('category');
		        $insertData['stock'] = ($this->input->post('inputStock'))?"1":"0";
		        $value = $this->Products_model->updateProduct($insertData, $id);

		        if($value)
		        {
		        	$this->session->set_flashdata('authErr', 'Product successfully Updated.');
		        	redirect(base_url('products'));
		        }
		        else
		        {
		            $this->session->set_flashdata('authErr', 'No changes!');
		            $data 				= $this->Products_model->getProductData($id);
		            $data['title']		="Edit Product";
					$data['breadcrumb']	="Product &gt; Edit Product";
					$data['category']	= array("Cloth", "Bag", "Mobile", "Computer");
					$this->load->view('edit_product',$data);
		        }
		    }

		}else{

			$data 				= $this->Products_model->getProductData($id);
			$data['title']		="Edit Product";
			$data['breadcrumb']	="Product &gt; Edit Product";
			$data['category']	= array("Cloth", "Bag", "Mobile", "Computer");
			$data['id']			= $id;
			$this->load->view('edit_product',$data);
		}
	}

public function do_upload($name){
	$config = array(
				'upload_path' => "./assets/uploads/",
				'allowed_types' => "gif|jpg|png|jpeg|pdf",
				'overwrite' => TRUE,
				'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
				'max_height' => "768",
				'max_width' => "1024",
				'file_name' => $name,
				);

				$this->load->library('upload', $config);
				if($this->upload->do_upload('productFile'))
				{
					return array('upload_data' => $this->upload->data());
				}else{
					$this->session->set_flashdata('authErr', $this->upload->display_errors());
		        	redirect(base_url('products'));
				}
	}

	public function deleteProduct($id){
		$value = $this->Products_model->deleteProduct($id);

        if($value)
        {
        	$this->session->set_flashdata('authErr', 'Product successfully Deleted!');
        	redirect(base_url('products'));
        }
	}
}
