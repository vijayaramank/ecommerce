<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
		parent::__construct();
	}

	public function index()
	{
		//echo "<pre>";print($this->session->all_userdata());
		$this->load->view('home');
	}
	public function dashboard()
	{
		isLogedIn();
		$this->load->model('Products_model');
		$data['productCount'] 	= $this->Products_model->recordsTotal();
		$data['instockCount'] 	= $this->Products_model->instockCount();
		$data['oosCount'] 		= $this->Products_model->oosCount();
		$this->load->view('template', $data);
	}
	public function my404()
	{
		$this->load->view('404');
	}
	public function loadData($limit=""){
		$this->load->model('Products_model');
		$startLimit 	= (($limit-9)<1?0:($limit-9));
		$lengthLimit 	= $limit;

		$list['data'] 			= $this->Products_model->getProductDetails($startLimit, $lengthLimit);
		$list['recordsTotal'] 	= $this->Products_model->recordsTotal();
		$list['recordsFiltered']= $this->Products_model->recordsTotal();

		//echo "<pre>";print_r($list['data']);exit;

		$data="";
		$dataTmp = "";
		$cardCount=0;
		foreach($list['data'] as $row){
			$dataTmp .= '<div class="card">
						    <div class="text-center">
						    <img src="'.base_url().'/assets/uploads/'.$row->image.'" class="img-thumbnail" alt="...">
						    </div>
						    <div class="card-body">
						      <h5 class="card-title">'.$row->name.'</h5>
						      <p class="card-text">'.$row->short_description.'</p>
						    </div>
						    <div class="card-footer">
						      <span class="h6 text-success">Price : $'.$row->price.'</span><br>
						      <span class="h6 text-danger">Was Price : <span class="text-decoration-line-through">$'.$row->was_price.'</span></span>
						    </div>

						  </div>';
						  $cardCount++;
						  if($cardCount == 3){
						  	$data .= '<div class="card-group">'.$dataTmp.'</div>';
						  	$dataTmp = "";
						  	$cardCount = 0;
						  }	  	
			}
			$data .= '<div class="card-group">'.$dataTmp.'</div>';
	  	
			echo $data;	
		
	}

}
