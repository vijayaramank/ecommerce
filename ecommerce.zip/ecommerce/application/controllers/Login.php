<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Login_model');
	}


	public function index()
	{
	    $this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('password','Password','required');

	    if($this->form_validation->run() == false)
	    {
	        $this->load->view('login');
	    }
	    else
	    {

	        $username = $this->input->post('email');
	        $password = $this->input->post('password');

	        $value = $this->Login_model->login($username,md5($password));

	        if($value)
	        {
	        	$this->session->set_userdata("uid", $this->Login_model->uid);
	        	$this->session->set_userdata("username", $this->Login_model->userName);
	        	$this->session->set_userdata("lase_login", $this->Login_model->lastLogin);
	            redirect('dashboard');
	        }
	        else
	        {
	            $this->session->set_flashdata('authErr', 'Email address or Password is incorrect!');
	             $this->load->view('login');
	        }
	    }

	}//end index function

	public function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}

}
