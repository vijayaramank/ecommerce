$(document).ready(function(){
    $('#datatablesSimple').DataTable( {
        responsive: true
    } )
});