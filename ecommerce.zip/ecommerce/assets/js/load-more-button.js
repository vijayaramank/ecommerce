$( document ).ready(function () {
  var scount = 3; 
  $(".moreBox").slice(0, 3).show();
    if ($(".blogBox:hidden").length != 0) {
      $("#loadMore").show();
    }   
    $("#loadMore").on('click', function (e) {
      e.preventDefault();
      $.ajax({
            url: "http://localhost/ecommerce/aj.txt",
            async: false,
            success: function (data){
                  $("#products").append(data);
            }
        });
  });
});